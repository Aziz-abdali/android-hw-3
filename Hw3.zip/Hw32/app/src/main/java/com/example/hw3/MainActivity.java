package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText b =findViewById(R.id.editTextTextPersonName8);
        final EditText c =findViewById(R.id.editTextTextPersonName4);
        final EditText s =findViewById(R.id.editTextTextPersonName5);
        final EditText g =findViewById(R.id.editTextTextPersonName6);
        final EditText z =findViewById(R.id.editTextTextPersonName7);
        Button x=findViewById(R.id.button);

        x.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
              String name = c.getText().toString();
              String yourjob = g.getText().toString();
              int age = s.getText().length();
              int phonenumber = z.getText().length();
              String email = b.getText().toString();

                Intent a =new Intent(MainActivity.this,MainActivity2.class);
                a.putExtra("info",name);
                a.putExtra("info1",age);
                a.putExtra("info2",yourjob);
                a.putExtra("info3",phonenumber);
                a.putExtra("info4",email);

                startActivity(a);
            }
        });
    }
}