package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView x =findViewById(R.id.textView);
        TextView x1 =findViewById(R.id.textView2);
        TextView x2 =findViewById(R.id.textView3);
        TextView x3 =findViewById(R.id.textView4);
        TextView x4 =findViewById(R.id.textView5);

        Bundle p =getIntent().getExtras();
        String bag = p.getString("info");
        String bag1 = p.getString("info2");
        String bag2 = p.getString("info4");
        int bag3 = p.getInt("info1");
        int bag4 = p.getInt("info3");

        x.setText(bag);
        x.setText(bag1);
        x.setText(bag2);
        x.setText(bag3);
        x.setText(bag4);

        Button k =findViewById(R.id.button2);
        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent g =new Intent(MainActivity2.this,MainActivity.class);
                startActivity(g);
            }
        });
    }
}